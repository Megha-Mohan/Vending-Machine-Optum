﻿using NUnit.Framework;

namespace VendingMachine
{
    [TestFixture]
    class CoinCollectionTests
    {
        VendingMachine vm;

        [SetUp]
        public void Init()
        {
            vm = new VendingMachine();
        }

        [Test]
        public void Coin_InsertQuarter_ValueBecomes25()
        {
            vm.Insert(Coin.Quarter, 1);
            Assert.That(25, Is.EqualTo(vm.CoinSlot.Value));
        }

        [Test]
        public void Coin_InsertDime_ValueBecomes10()
        {
            vm.Insert(Coin.Dime, 1);
            Assert.That(10, Is.EqualTo(vm.CoinSlot.Value));
        }

        [Test]
        public void Coin_InsertNickel_ValueBecomes5()
        {
            vm.Insert(Coin.Nickel, 1);
            Assert.That(5, Is.EqualTo(vm.CoinSlot.Value));
        }

        
        [Test]
        public void Coin_AddingCoinsAccumulatesValue_OneOfEachCoinIs40()
        {
            vm.Insert(Coin.Quarter, 1);
            vm.Insert(Coin.Nickel, 1);
            vm.Insert(Coin.Dime, 1);
            vm.Insert(Coin.Penny, 1);
            Assert.That(40, Is.EqualTo(vm.CoinSlot.Value));
        }


    }
}
