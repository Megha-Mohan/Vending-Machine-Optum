﻿using NUnit.Framework;


namespace VendingMachine
{
    [TestFixture]
    class VendingMachineTests
    {
        VendingMachine vm;

        [SetUp]
        public void Init()
        {
            vm = new VendingMachine();
        }

        [Test]
        public void AcceptCoins_Quarters_CoinSlotContainsQuarters()
        {
            vm.Insert(Coin.Quarter, 3);
            Assert.That(3, Is.EqualTo(vm.CoinSlot.Count(Coin.Quarter)));
        }

        [Test]
        public void AcceptCoins_Dimes_CoinSlotContainsDimes()
        {
            vm.Insert(Coin.Dime, 1);
            Assert.That(1, Is.EqualTo(vm.CoinSlot.Count(Coin.Dime)));
        }

        [Test]
        public void AcceptCoins_Nickels_CoinSlotContainsNickels()
        {
            vm.Insert(Coin.Nickel, 10);
            Assert.That(10, Is.EqualTo(vm.CoinSlot.Count(Coin.Nickel)));
        }


        [Test]
        public void AcceptCoins_DisplayValueWhenCoinSlotIsNotEmpty_Display25CentsWhenQuarterIsInserted()
        {
            vm.Insert(Coin.Quarter, 1);
            Assert.That("$0.25", Is.EqualTo(vm.Display));
        }


        [Test]
        public void ReturnCoins_CoinSlotEmptied_DisplayShowsInsertCoins()
        {
          
            vm.Insert(Coin.Quarter, 4);
            vm.ReturnCoins();
            string display = vm.Display;
            Assert.That("INSERT COINS", Is.EqualTo(display));
        }

    }
}
