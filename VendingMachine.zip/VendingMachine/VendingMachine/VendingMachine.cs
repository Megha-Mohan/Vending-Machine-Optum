﻿
namespace VendingMachine
{
    public class VendingMachine
    {
        //Constructor
        public VendingMachine()
        {
            CoinSlot = new CoinCollection();
            CoinReturn = new CoinCollection();
            
        }
        

       //Properties

       
        public CoinCollection CoinSlot { get; private set; }

       
        public CoinCollection CoinReturn { get; private set; }



        // The display shows status messages as well as the current amount of money in the coin slot.
        public string Display 
        { 
            get
            {
                string display;

                
                if(CoinSlot.Value == 0)
                {
                   
                        // If the coin slot is empty
                        // tell the user to add money.
                        display = "INSERT COINS";
                   
                }
                else
                {
                    display = CreateCurrencyString(CoinSlot.Value);
                }

                return display;
            }
        }

        // Placeholder for an explicit status string that has
        // to be displayed.
        private string TemporaryDisplay { get; set; }

        // Methods

        // Insert coins into the coin slot.
        public void Insert(Coin coin, int num)
        {
            if (coin == Coin.Penny)
            {
                CoinReturn.Insert(coin, num);
            }
            else
            {
                CoinSlot.Insert(coin, num);
            }
        }

      

        // Dispense available products. 
        
        public string Dispense(Product product)
        {
            int price = GetPrice(product);

           
            if(CoinSlot.Value >= price)
            {
                // There's enough money and an item
                // to dispense.

                TemporaryDisplay = "THANK YOU";
                CoinSlot.EmptyInto(CoinReturn);
            }
            else
            {
                // If there isn't enough money to pay for an item
                TemporaryDisplay = "PRICE " + CreateCurrencyString(price);
            }
            return TemporaryDisplay;
        }

        // Return all coins back to the user.
        public void ReturnCoins()
        {
            CoinSlot.EmptyInto(CoinReturn);
        }

        public int GetPrice(Product product)
        {
            int price = 0;
            if (product == Product.Cola)
            {
                price = 100;
            }
            else if(product == Product.Chips)
            {
                price = 50;
            }
            else if(product == Product.Candy)
            {
                price = 65;
            }

            return price;
        }
      

        
        public string CreateCurrencyString(int amount)
        {
            return string.Format("${0}", amount / 100.0);
        }
       
    }
}
