﻿using System;
using System.Collections.Generic;

namespace VendingMachine
{
    public class CoinCollection
    {
        // Constructor
        public CoinCollection()
        {
            Coins = new Dictionary<Coin, int>();
        }
       

       // Properties

        // Total amount of money in the collection.
        public int Value
        {
            get
            {
                return
                    Count(Coin.Quarter) * CoinValue(Coin.Quarter) +
                    Count(Coin.Dime) * CoinValue(Coin.Dime) +
                    Count(Coin.Nickel) * CoinValue(Coin.Nickel); 
                   
            }
        }

        private Dictionary<Coin, int> Coins { get; set; }

        

        // Methods
        // Insert coin into the collection
        internal void Insert(Coin coin, int num)
        {
            if(Coins.ContainsKey(coin))
            {
                Coins[coin] += num;
            }
            else
            {
                Coins.Add(coin, num);
            }


        }

        

        // Empty this collection 
        internal void EmptyInto(CoinCollection collection)
        {
            foreach (var kvp in Coins)
            {
                collection.Insert(kvp.Key, kvp.Value);
            }
            Coins.Clear();
        }

        

        public int Count(Coin coin)
        {
            int count = 0;
            if(Coins.ContainsKey(coin))
            {
                count = Coins[coin];
            }

            return count;
        }

       // Utility
        private int CoinValue(Coin coin)
        {
            int value = 0;

            if (coin == Coin.Quarter)
            {
                value = 25;
            }
            else if (coin == Coin.Dime)
            {
                value = 10;
            }
            else if (coin == Coin.Nickel)
            {
                value = 5;
            }

            return value;
        }

       
    }
}
