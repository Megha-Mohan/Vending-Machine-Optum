﻿
namespace VendingMachine
{
    public enum Coin
    {
        Penny,
        Nickel,
        Dime,
        Quarter
    };
}
