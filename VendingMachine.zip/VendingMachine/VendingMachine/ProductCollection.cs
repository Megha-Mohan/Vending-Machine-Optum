﻿using System.Collections.Generic;

namespace VendingMachine
{
    public class ProductCollection
    {
        #region Properties
        private Dictionary<Product, int> Products { get; set; }
        #endregion

        #region Constructor
        public ProductCollection()
        {
            Products = new Dictionary<Product, int>();
        }
        #endregion

        #region Methods
      
        internal void Dispense(Product product)
        {
            int count = Count(product);
            if(count > 0)
            {
                Products[product] = count - 1;
            }
        }

        public int Count(Product product)
        {
            int count = 0;
            if(Products.ContainsKey(product))
            {
                count = Products[product];
            }

            return count;
        }
        #endregion
    }
}
