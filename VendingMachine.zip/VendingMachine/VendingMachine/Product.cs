﻿
namespace VendingMachine
{
    public enum Product
    {
        Cola,
        Candy,
        Chips
    };
}
