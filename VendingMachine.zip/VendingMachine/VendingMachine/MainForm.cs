namespace VendingMachine
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

      
        //Deposit Button Click Handler
        private void Deposit_Click(object sender, EventArgs e)
        {
            DepositPurchase form = new DepositPurchase();
            form.ShowDialog();
            this.Hide();
        }

    }
}