﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace VendingMachine
{
    public partial class DepositPurchase : Form
    {

        VendingMachine vendingMachine = new VendingMachine();
        public DepositPurchase()
        {
            InitializeComponent();

            //Display Balance 
            label2.Text = vendingMachine.Display;

            //Initialise the dropdown
            CoinType.DataSource = Enum.GetValues(typeof(Coin));
            ProductType.DataSource = Enum.GetValues(typeof(Product));

        }

        // Deposit button click handler
        private void btn_Deposit_Click(object sender, EventArgs e)
        {

            int coinCount = Convert.ToInt32(Count.Text);
            Coin coinType = (Coin)this.CoinType.SelectedValue;
            vendingMachine.Insert(coinType, coinCount);

            //Update balance display
            label2.Text = vendingMachine.Display;
        }

        // Purchase button click handler
        private void Purchase_Click(object sender, EventArgs e)
        {
            Product productType = (Product)this.ProductType.SelectedValue;
            MessageBox.Show(vendingMachine.Dispense(productType));

            //Update balance display
            label2.Text = vendingMachine.Display;
        }
    }
}
